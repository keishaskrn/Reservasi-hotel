from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS kamar (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT,
            tipe TEXT,
            harga INTEGER
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS reservasi (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT,
            email TEXT,
            id_kamar INTEGER,
            tanggal TEXT
        )
    ''')
    c.execute("SELECT COUNT(*) FROM kamar")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO kamar (nama, tipe, harga) VALUES ('Deluxe Room', 'Double', 500000)")
        c.execute("INSERT INTO kamar (nama, tipe, harga) VALUES ('Suite Room', 'King', 1000000)")
        c.execute("INSERT INTO kamar (nama, tipe, harga) VALUES ('Standard Room', 'Single', 300000)")
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/kamar')
def kamar():
    conn = sqlite3.connect('database.db')
    kamar = conn.execute('SELECT * FROM kamar').fetchall()
    conn.close()
    return render_template('kamar.html', kamar=kamar)

@app.route('/reservasi', methods=['GET', 'POST'])
def reservasi():
    conn = sqlite3.connect('database.db')
    kamar = conn.execute('SELECT * FROM kamar').fetchall()
    if request.method == 'POST':
        nama = request.form['nama']
        email = request.form['email']
        id_kamar = request.form['id_kamar']
        tanggal = request.form['tanggal']
        if nama and email and tanggal:
            conn.execute('INSERT INTO reservasi (nama, email, id_kamar, tanggal) VALUES (?, ?, ?, ?)',
                         (nama, email, id_kamar, tanggal))
            conn.commit()
            conn.close()
            return redirect(url_for('riwayat'))
    return render_template('reservasi.html', kamar=kamar)

@app.route('/riwayat')
def riwayat():
    conn = sqlite3.connect('database.db')
    hasil = conn.execute('''
        SELECT r.id, r.nama, r.email, k.nama, r.tanggal
        FROM reservasi r
        JOIN kamar k ON r.id_kamar = k.id
    ''').fetchall()
    conn.close()
    return render_template('riwayat.html', hasil=hasil)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == 'admin':
            return redirect(url_for('home'))
    return render_template('login.html')

if __name__ == '__main__':
    app.run(debug=True)
